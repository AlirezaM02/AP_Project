#ifndef CATTLE_H
#define CATTLE_H

#include <QMainWindow>

namespace Ui {
class cattle;
}

class cattle : public QMainWindow
{
    Q_OBJECT

public:
    explicit cattle(QWidget *parent = nullptr);
    ~cattle();

private:
    Ui::cattle *ui;
};

#endif // CATTLE_H
