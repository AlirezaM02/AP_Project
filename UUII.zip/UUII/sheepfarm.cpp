#include "sheepfarm.h"
#include "ui_sheepfarm.h"

sheepfarm::sheepfarm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::sheepfarm)
{
    ui->setupUi(this);
}

sheepfarm::~sheepfarm()
{
    delete ui;
}
