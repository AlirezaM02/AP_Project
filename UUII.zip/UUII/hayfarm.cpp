#include "hayfarm.h"
#include "ui_hayfarm.h"

hayfarm::hayfarm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::hayfarm)
{
    ui->setupUi(this);
}

hayfarm::~hayfarm()
{
    delete ui;
}
