#include "secondpage.h"
#include "ui_secondpage.h"

secondpage::secondpage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::secondpage)
{
    ui->setupUi(this);
}

secondpage::~secondpage()
{
    delete ui;
}
