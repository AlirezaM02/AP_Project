#ifndef HEYFARM_H
#define HEYFARM_H

#include <QMainWindow>

namespace Ui {
class heyfarm;
}

class heyfarm : public QMainWindow
{
    Q_OBJECT

public:
    explicit heyfarm(QWidget *parent = nullptr);
    ~heyfarm();

private:
    Ui::heyfarm *ui;
};

#endif // HEYFARM_H
