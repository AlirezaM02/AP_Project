#ifndef SECONDPAGE_H
#define SECONDPAGE_H

#include <QMainWindow>

namespace Ui {
class secondpage;
}

class secondpage : public QMainWindow
{
    Q_OBJECT

public:
    explicit secondpage(QWidget *parent = nullptr);
    ~secondpage();

private:
    Ui::secondpage *ui;
};

#endif // SECONDPAGE_H
