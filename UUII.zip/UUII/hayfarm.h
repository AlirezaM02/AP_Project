#ifndef HAYFARM_H
#define HAYFARM_H

#include <QMainWindow>

namespace Ui {
class hayfarm;
}

class hayfarm : public QMainWindow
{
    Q_OBJECT

public:
    explicit hayfarm(QWidget *parent = nullptr);
    ~hayfarm();

private:
    Ui::hayfarm *ui;
};

#endif // HAYFARM_H
