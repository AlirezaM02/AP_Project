#ifndef SHEEPFARM_H
#define SHEEPFARM_H

#include <QMainWindow>

namespace Ui {
class sheepfarm;
}

class sheepfarm : public QMainWindow
{
    Q_OBJECT

public:
    explicit sheepfarm(QWidget *parent = nullptr);
    ~sheepfarm();

private:
    Ui::sheepfarm *ui;
};

#endif // SHEEPFARM_H
