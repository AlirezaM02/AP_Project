#ifndef WHEATFARM_H
#define WHEATFARM_H

#include <QMainWindow>

namespace Ui {
class wheatfarm;
}

class wheatfarm : public QMainWindow
{
    Q_OBJECT

public:
    explicit wheatfarm(QWidget *parent = nullptr);
    ~wheatfarm();

private:
    Ui::wheatfarm *ui;
};

#endif // WHEATFARM_H
