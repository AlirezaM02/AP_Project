#include "cattle.h"
#include "ui_cattle.h"

cattle::cattle(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::cattle)
{
    ui->setupUi(this);
}

cattle::~cattle()
{
    delete ui;
}
