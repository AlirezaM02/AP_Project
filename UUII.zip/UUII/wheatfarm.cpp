#include "wheatfarm.h"
#include "ui_wheatfarm.h"

wheatfarm::wheatfarm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::wheatfarm)
{
    ui->setupUi(this);
}

wheatfarm::~wheatfarm()
{
    delete ui;
}
