#include "heyfarm.h"
#include "ui_heyfarm.h"

heyfarm::heyfarm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::heyfarm)
{
    ui->setupUi(this);
}

heyfarm::~heyfarm()
{
    delete ui;
}
